<html>
<head>
    <title>QUIZ MAKER - n. domande per ogni argomento </title>  
</head>

<body>
 
<?php
class user {
	public
  $iduser,
		$email,
		$psw;
		
  public function utente()
		{
				//svolge alcuni controlli
				//....
				
				//e altre elaborazioni
				//...
				
				return $this->iduser.":".$this->email.":".$this->psw;					
		}		
}

?>

<?php
	 include($_SERVER['DOCUMENT_ROOT']."\..\my_include\setup.php");
		
  //recupero credenziali da file ESTERNO alla cartella pubblica del sito
  $accessData=parse_ini_file('..\..\..\my_ini\configDB.ini');
		
				try 
				{
      //CONNESSIONE
      $conn_pdo = new PDO("mysql:host=localhost;dbname={$accessData['dbname']}",
																		$accessData['username'],$accessData['password']); 
				}
				
		  catch (PDOException $e)
		  {
      echo $e->getMessage() . "<br/>";
				  echo "Connessione al server fallita. Impossibile procedere. Contattare ...";
      die();
		  }								
  
  //ATTIVAZIONE ECCEZIONI PER METODO QUERY 
		$conn_pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);	  
	
		$comandoSQL = "select argomento, count(*) as 'numero_domande' ".
                "from argomenti join domande on idargomento=fkargomento ".
                "group by argomento ".
                "order by argomento";			
  try
		{
  		$risultato = $conn_pdo->query($comandoSQL);			
		}
		
		catch (PDOException $e)
		{
    echo $e->getMessage() . "<br/>";
				echo "Nessun risultato ottenuto  ...";
				
    die();
		}

	
	//fetch mode di default: PDO::FETCH_BOTH (associativo e per n. colonna)
	while ( $riga = $risultato->fetch() )
	{
		 //usando i nomi delle colonne restituite
			echo $riga['argomento'].": ".$riga['numero_domande'].$nl;

		 //usando le posizioni delle colonne restituite
			echo $riga[0].": ".$riga[1].$nl;

	}
 echo "-------------------------------".$nl;
	
	//fetch mode PDO::FETCH_CLASS
	$risultato = $conn_pdo->query("select * from users",
																															PDO::FETCH_CLASS,
																															"user") ;
	
	while ( $oggetto = $risultato->fetch() )
		 echo $oggetto->utente().$nl;


 echo "-------------------------------".$nl;
	
	//fetch con cursore (non supportati da MySql)
	//attiviamo modalita' con cursore
	$conn_pdo->setAttribute(PDO::ATTR_CURSOR, PDO::CURSOR_SCROLL);
	
	$risultato = $conn_pdo->query("select * from users");
	
	//in avanti
	while ( $riga = $risultato->fetch(PDO::FETCH_ASSOC, PDO::FETCH_ORI_NEXT) )
		 echo $riga['iduser'].": ".$riga['email'].$nl;
 
	echo "-------------------------------".$nl;

	
//ed ora all'indietro
$risultato = $conn_pdo->query("select * from users");

$stmt = $conn_pdo->prepare("select * from users",
																											array(PDO::ATTR_CURSOR => PDO::CURSOR_SCROLL));
$stmt->execute();

$riga=$stmt->fetch(PDO::FETCH_ASSOC, PDO::FETCH_ORI_LAST);
// a ritroso ...
	do
	{
		 echo $riga['iduser'].": ".$riga['email'].$nl;
	} while ( $riga = $stmt->fetch(PDO::FETCH_ASSOC, PDO::FETCH_ORI_PRIOR) );

	$stmt->closeCursor();
	
 //CHIUDIAMO LA CONNESSIONE E LIBERIAMO LE RISORSE OCCUPATE ...
		$conn=null;

?>


</body>
</html>