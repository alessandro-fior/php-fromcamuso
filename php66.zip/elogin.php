<?php
  include($_SERVER['DOCUMENT_ROOT']."\..\my_include\setup.php");

   //recupero credenziali da file ESTERNO alla cartella pubblica del sito
   $accessData=parse_ini_file('..\..\..\my_ini\configDB.ini');
  
  //prima di tutto un po' di sicurezza ...
  if ($_SERVER['REQUEST_METHOD'] == 'POST')
  {
    //ok la pagina � stata davvero richiamata dalla form
    
    //recupero il contenuto della textbox email
    $email = $_POST['email'];
    
    //... quello della textbox password
    $psw = $_POST['password'];
    
    //... e il tipo utente
    $tipo_utente = $_POST['tipo_utente'];
    
    
    //1 stabilire una (o pi�) connessione/i con un server
    //NB: con @ si sopprimono i warning/errori del comando
    $conn = @mysqli_connect("localhost",$accessData['username'],$accessData['password']);
         
    if(!$conn)
    {//gestione dell'errore
      
        //echo mysqli_connect_errno() . $nl;
        //echo mysqli_connect_error() . $nl;
        //echo mysqli_sqlstate( $conn ) . $nl;
        echo "Connessione al server fallita. Impossibile procedere. Contattare ...";
        die;  
     }
       
    //2 selezionare il db con cui lavorare
    if ( !@mysqli_select_db($conn, $accessData['dbname']) )
    {
      echo "Non trovo il data base ...".$nl;
      echo mysqli_sqlstate( $conn ) . $nl;
      echo mysqli_errno( $conn ) . $nl;
      echo mysqli_error( $conn ) . $nl;
      die;       
    }
    
    $comandoSQL =
      "select iduser, psw, tipo_utente from users where email ='" . mysqli_escape_string($conn, $email) ."'";
          
    //2 inviare il comando
    $risultatoRicercaEmail = @mysqli_query($conn, $comandoSQL);
 
     
    //quale bottone � stato premuto, 'accedi' o 'nuovo utente'?
    if (isset($_POST['btnAccedi']))
    {
              
     if ($risultatoRicercaEmail) //la query ha avuto successo
     {
       
       //3 elaborare il risultato
       if ($riga = mysqli_fetch_assoc($risultatoRicercaEmail) ) //mail trovata, confrontiamo psw
       {
          $autenticato = ($psw === $riga['psw']);
       }
       else
       {
         $autenticato = false;
       }
                    
       //4 chiudere la/le connessione/i
       mysqli_close($conn);
  
       //redirect
       if($autenticato)
       {
         $_SESSION['iduser']=$riga['iduser'];
         $_SESSION['tipo_utente']=$riga['tipo_utente'];
         
         header("Location: main.php");
       }
       else
         header("Location: login.php?errore=autenticazione_fallita");
         
       exit;
     }
     else //fallita mysqli_query
     {
      echo "Problemi con il server data base ...".$nl;
      echo mysqli_sqlstate( $conn ) . $nl;
      echo mysqli_errno( $conn ) . $nl;
      echo mysqli_error( $conn ) . $nl;
      die;  
     }
    }
    else
    {
      //BOTTONE NUOVO UTENTE
      if ( mysqli_fetch_assoc($risultatoRicercaEmail) )
      {
        mysqli_close($conn);
        header("Location: login.php?errore=email_gia_inserita"); //email gia' presente
        exit;
      }
      
      //insert into users values (null, 'e@j.com','eee')
      //$comandoSQL = "insert into users values (null,'".$email."','".$psw."')";
      $comandoSQL = "insert into users values (null,'$email','$psw','$tipo_utente')";
      $esito = mysqli_query($conn, $comandoSQL);
        
      if ($esito)
      {
        $_SESSION['iduser'] = mysqli_insert_id( $conn );
        $_SESSION['tipo_utente']=$riga['tipo_utente'];
        
        mysqli_close($conn);
        header("Location: main.php");
      }
      else
      {
        mysqli_close($conn);
        header("Location: login.php?errore=inserimento_fallito"); //inserimento fallito
      }
     
      exit;
        
    }
}
else
{
  header("Location: login.php?errore=4"); //non autenticato
  exit; 
 
}
  
  
  
  

?>

</body>
</html>