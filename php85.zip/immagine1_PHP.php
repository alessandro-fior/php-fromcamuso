<?php
 $immagine = imagecreatetruecolor(100, 100);
 $rosso = imagecolorallocate($immagine, 0xFF, 0x00, 0x00);
 imagefilledrectangle($immagine, 10, 10, 60, 60, $rosso);

 header("Content-Type: image/png");
 imagepng($immagine);
?>
