<?php
 $immagine = imagecreatetruecolor(100, 100);
 $blu = imagecolorallocate($immagine, 0x00, 0x00, 0xFF);
 imagefilledrectangle($immagine, 40, 40, 80, 80, $blu);

  header("Content-Type: image/png");
  imagepng($immagine);
?>
