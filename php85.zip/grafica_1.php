<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
	<title>Untitled</title>
</head>

<body>

<body>
Immagini generate da PHP <br />
<img src="immagine1_PHP.php" alt="Image 1" />
<img src="immagine2_PHP.php" alt="Image 2" />
</body>
</html>
