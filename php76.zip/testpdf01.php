<?php
require("fpdf.php"); // path to fpdf.php

//INIZIALIZZAZIONI OBBLIGATORIE
$pdf = new FPDF(); //istanziamo un oggetto fpdf
$pdf->addPage(); //aggiungiamo la prima pagina
$font_size=16;

$pdf->setFont("Arial", 'B', 16); //obbligatorio

//AGGIUNTA DI ELEMENTI SULLE PAGINE (TESTO, IMMAGINI)
//$pdf->cell(40, 70, "Il mio primo documento PDF!",1);
pdf_echo($pdf, "Il mio primo documento PDF!", $font_size,0,1);

for($i=0; $i<10; $i++)
  pdf_echo($pdf, $i, $font_size,0,1);
  
//GENERAZIONE DEL DOCUMENTO 
$pdf->output();


//FUNZIONI DI SUPPORTO
function pdf_setFont($pdf, &$font_size, $punti)
{
  $pdf->setFont($punti);
  $font_size=$punti;
}

function pdf_echo($pdf, $riga, $font_size, $cornice=0, $a_capo=0)
{  
  $pdf->Cell( $pdf->GetStringWidth($riga), $font_size*0.35, $riga, $cornice,$a_capo); 
}
?>