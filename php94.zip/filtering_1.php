<?php
//TECNICA DELLA CONSEGNA (DISPATCHING)
//Credits to: http://phpsec.org/projects/guide/1.html#1.4

/* misure globali di sicurezza
 - sessioni sicure
 - autenticazione
 - controllo ip
 - controllo agent di provenienza
 - ecc.
*/

//si arriva a questo script da una form con action (o link) del tipo:
//  action="www.sito.com/filtering_1.php?task=stampa_form"

switch ($_GET['task'])
{
    case 'stampa_form':
        include $_SERVER['DOCUMENT_ROOT'].'\..\my_include\presentation\form.inc';
        break;

    case 'elabora_form':
        $form_valida = false;								
        include include $_SERVER['DOCUMENT_ROOT'].'\..\my_include\logic\process.inc';
        
								if ($form_valida)
        {
            include $_SERVER['DOCUMENT_ROOT'].'\..\my_include\presentation\end.inc';
        }
        else
        {
            include include $_SERVER['DOCUMENT_ROOT'].'\..\my_include\presentation\form.inc';
        }
        break;

    default:
        include include $_SERVER['DOCUMENT_ROOT'].'\..\my_include\presentation\index.inc';
        break;
}


?>
