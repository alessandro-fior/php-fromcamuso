<?php
  @session_start();
		if (  !isset($_SESSION['iduser']) )
		{
		  header("Location: login.php?errore=autenticazione_richiesta"); //user non autenticato
				exit;
		}
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
	<title>PANNELLO CONTROLLO</title>
</head>

<body>
Funzioni disponibili: </br>
<ul>
<?php
		$tipo_utente = $_SESSION['tipo_utente'];
		
		if ($tipo_utente=='docente')
		{//generiamo interfaccia per il docente
			
			echo "<li> <a href='gestione_argomenti.php'> Gestione Argomenti </a> </li>\n";
			echo "<li> <a href='gestione_domande.php'> Gestione Domande </a> </li>\n";
			echo "<li> <a href='crea_questionario.php'> Crea un questionario </a> </li>\n";
		}
		else
		; //qui dovremmo generare l'interfaccia per lo studente
?>
</ul>

</body>
</html>
