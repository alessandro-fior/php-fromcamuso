<?php
  include($_SERVER['DOCUMENT_ROOT']."\..\my_include\setup.php")
?>
<!DOCTYPE html>

<html>
<head>
    <title>QUIZ MAKER - LOGIN</title>
</head>

<body  style="background-color: lightgreen; ">
 <center> <h2> QUIZ MAKER LOGIN</h2> </center>
 
 <form name="login" action="elogin.php" method="POST">

    <table>
        <tr>
            <td>Email: </td>
            <td> <input type="text" name="email" value="" /></td>
        </tr>
        <tr>
            <td>Password: </td>
            <td> <input type="password" name="password" value=""
                        autocomplete="off" /></td>
        </tr>
    </table>
    Entra come: 
     Alunno  <input type="radio" name="tipo_utente" value="alunno" checked> 
     Docente <input type="radio" name="tipo_utente" value="docente"> <br> <br>
      
    <input type="submit" name="btnAccedi" value="ACCEDI" />
    <input type="submit" name="btnNuovo" value="NUOVO UTENTE" />
    <input type="reset"/>        
 </form>

 <?php
 if( isset($_GET['errore']) )
 {
    echo "<p id='box_errore'".
         " style='background-color: red; font-weight: bold; color: yellow; border: 2px solid white;'>";

  echo $messaggi_errore[$_GET['errore']];
  echo "</p>";
    
 }
 
 
 ?>
 
</body>
</html>













  