CREATE DATABASE  IF NOT EXISTS `quizmaker` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `quizmaker`;
-- MySQL dump 10.13  Distrib 5.6.13, for Win32 (x86)
--
-- Host: 127.0.0.1    Database: quizmaker
-- ------------------------------------------------------
-- Server version	5.6.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `argomenti`
--

DROP TABLE IF EXISTS `argomenti`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `argomenti` (
  `idargomento` int(11) NOT NULL AUTO_INCREMENT,
  `argomento` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idargomento`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `argomenti`
--

LOCK TABLES `argomenti` WRITE;
/*!40000 ALTER TABLE `argomenti` DISABLE KEYS */;
INSERT INTO `argomenti` VALUES (1,'storia'),(2,'geografia'),(3,'chimica'),(4,'informatica');
/*!40000 ALTER TABLE `argomenti` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `domande`
--

DROP TABLE IF EXISTS `domande`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `domande` (
  `iddomanda` int(11) NOT NULL AUTO_INCREMENT,
  `testo_domanda` varchar(200) DEFAULT NULL,
  `fkargomento` int(11) NOT NULL,
  PRIMARY KEY (`iddomanda`),
  KEY `fk_domande_argomenti_idx` (`fkargomento`),
  CONSTRAINT `fk_domande_argomenti` FOREIGN KEY (`fkargomento`) REFERENCES `argomenti` (`idargomento`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `domande`
--

LOCK TABLES `domande` WRITE;
/*!40000 ALTER TABLE `domande` DISABLE KEYS */;
INSERT INTO `domande` VALUES (1,'Se parliamo di centurioni ...',1),(2,'Napoleone visse all\'incirca nel ',1),(3,'La Russia confina con la Turchia?',2),(4,'Qual\'è il fiume più lungo della Francia?',2);
/*!40000 ALTER TABLE `domande` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `items`
--

DROP TABLE IF EXISTS `items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `items` (
  `idItem` int(11) NOT NULL AUTO_INCREMENT,
  `fkQuestionario` int(11) DEFAULT NULL,
  `fkDomanda` int(11) DEFAULT NULL,
  `questionari_users_iduser` int(11) NOT NULL,
  PRIMARY KEY (`idItem`,`questionari_users_iduser`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `items`
--

LOCK TABLES `items` WRITE;
/*!40000 ALTER TABLE `items` DISABLE KEYS */;
/*!40000 ALTER TABLE `items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `questionari`
--

DROP TABLE IF EXISTS `questionari`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `questionari` (
  `idquestionario` int(11) NOT NULL AUTO_INCREMENT,
  `descrizione_questionario` varchar(200) DEFAULT NULL,
  `data_creazione` datetime DEFAULT NULL,
  `fkUser` int(11) NOT NULL,
  PRIMARY KEY (`idquestionario`),
  KEY `fk_questionari_users1_idx` (`fkUser`),
  CONSTRAINT `fk_questionari_users1` FOREIGN KEY (`fkUser`) REFERENCES `users` (`iduser`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `questionari`
--

LOCK TABLES `questionari` WRITE;
/*!40000 ALTER TABLE `questionari` DISABLE KEYS */;
/*!40000 ALTER TABLE `questionari` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `questionari_svolti`
--

DROP TABLE IF EXISTS `questionari_svolti`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `questionari_svolti` (
  `idquestionario_svolto` int(11) NOT NULL AUTO_INCREMENT,
  `inizio` datetime DEFAULT NULL,
  `fine` varchar(45) DEFAULT NULL,
  `fkUser` int(11) NOT NULL,
  `fkQuestionario` int(11) NOT NULL,
  PRIMARY KEY (`idquestionario_svolto`),
  KEY `fk_questionari_svolti_users1_idx` (`fkUser`),
  KEY `fk_questionari_svolti_questionari1_idx` (`fkQuestionario`),
  CONSTRAINT `fk_questionari_svolti_questionari1` FOREIGN KEY (`fkQuestionario`) REFERENCES `questionari` (`idquestionario`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_questionari_svolti_users1` FOREIGN KEY (`fkUser`) REFERENCES `users` (`iduser`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `questionari_svolti`
--

LOCK TABLES `questionari_svolti` WRITE;
/*!40000 ALTER TABLE `questionari_svolti` DISABLE KEYS */;
/*!40000 ALTER TABLE `questionari_svolti` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `risposte`
--

DROP TABLE IF EXISTS `risposte`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `risposte` (
  `idrisposta` int(11) NOT NULL AUTO_INCREMENT,
  `testo_risposta` varchar(200) DEFAULT NULL,
  `punti` int(11) DEFAULT NULL,
  `fkDomanda` int(11) NOT NULL,
  PRIMARY KEY (`idrisposta`),
  KEY `fk_risposte_domande1_idx` (`fkDomanda`),
  CONSTRAINT `fk_risposte_domande1` FOREIGN KEY (`fkDomanda`) REFERENCES `domande` (`iddomanda`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `risposte`
--

LOCK TABLES `risposte` WRITE;
/*!40000 ALTER TABLE `risposte` DISABLE KEYS */;
INSERT INTO `risposte` VALUES (1,'siamo a Roma',3,1),(2,'siamo a Londra',-1,1),(3,'siamo ad Atene',1,1),(4,'sì',0,3),(5,'no',1,3);
/*!40000 ALTER TABLE `risposte` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `risposte_date`
--

DROP TABLE IF EXISTS `risposte_date`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `risposte_date` (
  `idrisposta_data` int(11) NOT NULL AUTO_INCREMENT,
  `fkDomanda` int(11) NOT NULL,
  `fkQuestionarioSvolto` int(11) NOT NULL,
  `fkrisposta` int(11) NOT NULL,
  PRIMARY KEY (`idrisposta_data`),
  KEY `fk_risposte_date_questionari_svolti1_idx` (`fkDomanda`),
  KEY `fk_risposte_date_domande1_idx` (`fkQuestionarioSvolto`),
  KEY `fk_risposte_date_risposte1_idx` (`fkrisposta`),
  CONSTRAINT `fk_risposte_date_domande1` FOREIGN KEY (`fkQuestionarioSvolto`) REFERENCES `domande` (`iddomanda`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_risposte_date_questionari_svolti1` FOREIGN KEY (`fkDomanda`) REFERENCES `questionari_svolti` (`idquestionario_svolto`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_risposte_date_risposte1` FOREIGN KEY (`fkrisposta`) REFERENCES `risposte` (`idrisposta`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `risposte_date`
--

LOCK TABLES `risposte_date` WRITE;
/*!40000 ALTER TABLE `risposte_date` DISABLE KEYS */;
/*!40000 ALTER TABLE `risposte_date` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `iduser` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(45) NOT NULL,
  `psw` varchar(45) NOT NULL,
  PRIMARY KEY (`iduser`),
  UNIQUE KEY `email_UNIQUE` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (51,'a@a.com','aaa'),(52,'b@b.com','bbb');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-03-23 21:59:14
