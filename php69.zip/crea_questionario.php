<?php
	 include($_SERVER['DOCUMENT_ROOT']."\..\my_include\setup.php");

		if (  !isset($_SESSION['iduser']) )
		{
		  header("Location: login.php?errore=autenticazione_richiesta"); //user non autenticato
				exit;
		}

  //recupero credenziali da file ESTERNO alla cartella pubblica del sito
  $accessData=parse_ini_file('..\..\..\my_ini\configDB.ini');
		
		//connessione e selezione db
		$conn = @mysqli_connect("localhost",$accessData['username'],$accessData['password']);  
				
		if(!$conn)
  { echo "Connessione al server fallita. Impossibile procedere. Contattare ...";
    die;  
  }
  
		if ( !@mysqli_select_db($conn, $accessData['dbname']) )
  {
    echo "Non trovo il data base ...";
    die;       
  }
		
		?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
	<title>CREAZIONE QUESTIONARIO</title>
</head>

<body>
<form name="argomento" action="crea_questionario.php" method="post">
Descrizione questionario:
<input type="text" name="descrizione"
//se siamo ritornati sulla pagina dopo aver scelto l'argomento riproponiamo
//la descrizione precedentemente inserita							
<?php
if( isset($_POST['descrizione']) )
			echo " value='".$_POST['descrizione']."'";
echo " />"; //fine input
?>
<br />

Scegliere un argomento_:
<select name="elenco_argomenti">
 <?php
	 //leggiamo elenco argomenti dalla tabella argomenti 
  $comandoSQL = "select * from argomenti";
		$risultato = @mysqli_query($conn, $comandoSQL);
		
		while ($riga = mysqli_fetch_assoc($risultato) )
		{
		  echo "<option value='".$riga['idargomento']."' ";
				
				//siamo ritornati su questa pagina dopo aver scelto l'argomento
				//e siamo sulla option corrispondente alla scelta fatta? -> selected
				if( isset($_POST['elenco_argomenti']) &&
							 $riga['idargomento']==$_POST['elenco_argomenti'])
				  echo "selected";
		
				echo "> ".$riga['argomento']."</option>\n";
		}
 ?>
</select>
<br />
<input type="submit" name="ok" value="Domande per l'argomento scelto" />

</form>

<?php
	 //solo se avevamo gi� scelto l'argomento crea una form con la lista delle domande
		//abbinabili
		if( isset($_POST['elenco_argomenti']) )
		{
		  echo "<form name='scelta_domande' action='registra_dati_questionario.php'".
				     " method='post'>";
		
		  //descrizione riproposta come campo nascosto ...
		  echo "<input type='hidden' value='".$_POST['descrizione']."' />";
	
		  echo "Scegli le domande che compongono il questionario ".$nl;
    $comandoSQL = "select * from domande where fkargomento='".
				              $_POST['elenco_argomenti']."'";
																			
		   $risultato = @mysqli_query($conn, $comandoSQL);
					while ($riga = mysqli_fetch_assoc($risultato) )
					{
						  echo "<input type='checkbox' name='domande_scelte[]' ".
								     "value='".$riga['iddomanda']."'>";
								echo $riga['testo_domanda']."\n".$nl;					
								
					}
			echo $nl."<input type='submit' name='ok' ".
			     "value='Registra i dati del questionario' />\n";
			echo "</form>";
			mysqli_close($conn);
		}
		else
		  mysqli_close($conn);
?>	

</body>
</html>
