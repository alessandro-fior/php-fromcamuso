<?php
  function a(  $accessData )
		{ 	b( $accessData ); }
		
		function b( $accessData )
		{
				try 
				{ connessione( $accessData ); }
				
		  catch (PDOException $e)
		  {
      echo $e->getMessage() . "<br/>";
				  echo "Connessione al server fallita. Impossibile procedere. Contattare ...";
      die();
		  }								
		
		}
		
		function connessione( $accessData )
		{
    //CONNESSIONE
    $conn = new PDO("mysql:host=localhost;dbname={$accessData['dbname']}",
																		$accessData['username'],"xxx"); //$accessData['password']);		 
		}
		
?>

<?php
	 include($_SERVER['DOCUMENT_ROOT']."\..\my_include\setup.php");
		
		if (  !isset($_SESSION['iduser']) )
		{
		  header("Location: login.php?errore=autenticazione_richiesta"); //user non autenticato
				exit;
		}

  //recupero credenziali da file ESTERNO alla cartella pubblica del sito
  $accessData=parse_ini_file('..\..\..\my_ini\configDB.ini');
		
  a( $accessData );
  
  //CHIUDIAMO LA CONNESSIONE E LIBERIAMO LE RISORSE OCCUPATE ...
		$conn=null;
?>


