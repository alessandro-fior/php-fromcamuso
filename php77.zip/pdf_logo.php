<?php
  require("fpdf.php"); // path to fpdf.php
  
  class my_PDF extends FPDF
  {   
    public function Header()
    {
      $testo = "Report modello SE80";
      $this->SetFont('Arial','B',8);
      $this->Cell($this->getPageWidth() - $this->GetStringWidth($testo),
                  10,$testo,0,0,'R');
    
      // Interruzione di linea 
      $this->Ln(20); //20 spaziatura tra intestazione e corpo pagina
    }
  
   public function Footer()
   {

    $this->SetTextColor(0,0,0);
    
    // Va a 1.5 cm dal fondo della pagina
    $this->SetY(-15);
   
    // Seleziona Arial corsivo 8
    $this->SetFont('Arial','I',8);
    
    // Stampa il numero di pagina centrato
    $this->Cell(0,10,'Pag. '.$this->PageNo(),0,0,'C');
   }
   
    public function get_font_size()
    {return $this->FontSize;}
       
  public function aggiungi_pagina()
  {
    $this->addPage(); 
    
    $this->Image("img\planks.jpg");
    
    $this->SetFillColor(255,0,0);
    $this->Rect(35, 30, 1,200,"F");
    $this->Rect(5, 55, 150,1,"F");
    
    $this->SetFont('Arial','B',16);
    $this->SetTextColor(0,0,255);
    
    $titolo = "Risultati quiz per ...";
    $this->SetXY(40, 40);
    $this->Cell( $this->GetStringWidth($titolo),
                $this->FontSize*0.35,
                $titolo );   
 }    
}
?>

<?php
  $pdf = new my_PDF();
  
  for ($pagina=1; $pagina<3; $pagina++)
  {
    $pdf->aggiungi_pagina();
    
    //contenuto di questa pagina ...
  }
  
  $pdf->output();
?>
