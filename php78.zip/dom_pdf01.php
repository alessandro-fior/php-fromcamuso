<?php
	 include($_SERVER['DOCUMENT_ROOT']."\..\my_include\setup.php");
		
  //ACCESSO E INVIO COMANDO SQL A MYSQL
  //recupero credenziali da file ESTERNO alla cartella pubblica del sito
  $accessData=parse_ini_file('..\..\..\my_ini\configDB.ini');
  
  require_once $_SERVER['DOCUMENT_ROOT'] . "/dompdf/autoload.inc.php";

		try 
		{
    //CONNESSIONE
    $conn_pdo = new PDO("mysql:host=localhost;dbname={$accessData['dbname']}",
        																$accessData['username'],$accessData['password']); 
		}
				
  catch (PDOException $e)
  {
    echo $e->getMessage() . "<br/>";
		  echo "Connessione al server fallita. Impossibile procedere. Contattare ...";
    die();
  }								
  
  //ATTIVAZIONE ECCEZIONI PER METODO QUERY 
		$conn_pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);	  
	
		$comandoSQL = "select argomento, count(*) as 'numero_domande' ".
                "from argomenti join domande on idargomento=fkargomento ".
                "group by argomento ".
                "order by argomento";			
  try
		{
  		$risultato = $conn_pdo->query($comandoSQL);			
		}
		
		catch (PDOException $e)
		{
    echo $e->getMessage() . "<br/>";
				echo "Nessun risultato ottenuto  ...";
				
    die();
		}

  //GENERAZIONE PDF  
  //accesso al namespace
  use Dompdf\Dompdf;

  // istanziamo un oggetto della classe Dompdf
  $pdf = new Dompdf();

  //prepariamo una stringa con HTML/CSS da convertire
  $html = <<<'FINE_STRINGA'
  <html>
    <body>  
      <p style='background-color: red; font-size:40px'>
              DOMPDF installato e pronto all'uso!! </br>
      </p>
      <p style='color: blue; font-size:15px; border: 1pt dashed red;'>
FINE_STRINGA;

//aggiungiamo alla stringa i dati letti dal DB
while ( $riga = $risultato->fetch() )
{
		 //usando i nomi delle colonne restituite
			$html = $html . $riga['argomento'].": ".$riga['numero_domande'].$nl;
   $html = $html .  "-------------------------------".$nl;
}

 $html = $html .
   "</p>" .
 "</body>" .
"</html>";


  $pdf->load_html($html);
  
  // opzionale: formato ed orientamento del document
  $pdf->setPaper('A4', 'portrait');
  
  // Rendering del pdf
  $pdf->render();

  // restituzione al browser (il pdf verr� scaricato nella cartella download)
  $pdf->stream("report.pdf");
?>






