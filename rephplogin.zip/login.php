<!DOCTYPE html>

<html>
<head>
    <title>LOGIN</title>
</head>
<?php
 $nl="<br />";
  $voci = array("upload", "ftp", "mail", "voip");
  
?>
<body>
 <form name="login" action="elogin.php" method="POST">

    <table>
        <tr>
            <td>Email: </td>
            <td> <input type="text" name="email" value="" autocomplete="off"/></td>
        </tr>
        <tr>
            <td>Password: </td>
            <td> <input type="password" name="password" value="" autocomplete="off" /></td>
        </tr>
    </table>
    
    <?php
      for ($numero=1; $numero<=20; $numero++ )
        echo $numero; 
    ?>    
    
    Upload <input type="radio" value="upload" name="secure" />
    FTP <input type="radio" value="ftp" name="secure" />
    mail <input type="radio" value="mail" name="secure" />
    Voip <input type="radio" value="Voip" name="secure" /><br /> <br />

    
    <input type="submit" value="INVIA" /> <input type="reset"/>
    
    
 </form>
 
 
 
</body>
</html>













  