<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
	<title>ELOGIN</title>
</head>

<body>

<?php
  //recuperiamo i dati dalla form
  $nl="<br />";
	
	$email = $_POST['email'];
	$password = $_POST['password'];
  
	if ( isset($_POST['secure']) )
		$secure=$_POST['secure'];
	else
		$secure="";
	
//	switch ( $secure )
//	{
//		case "upload":
//			echo "Upload sicuro attivato  " ;
//			
//		break;
//	
//		case "ftp":
//			echo "FTP sicuro attivato  " ;
//		break;
//	
//		case "mail":
//			echo "mail sicura attivata  " ;
//		break;
//
//		case "voip":
//			echo "Upload sicuro attivato  " ;
//		break;
//	
//    default:
//			  echo "Nessun servizio sicuro attivato  ";
//			break;
//	}
	
	
  switch ( $secure)
	{
		case "upload":
		case "ftp":
			echo "traferimento dati attivato  " ;
    break;
	
		case "mail":
			echo "mail sicura attivata  " ;
		break;

		case "voip":
			echo "Upload sicuro attivato  " ;
		break;
	
    default:
			  echo "Nessun servizio sicuro attivato  ";
			break;
	}
	
	
	echo $nl;
									//espressione condizionale 
	$secure = isset($_POST['secure']) ?  $_POST['secure'] : "";	
  		
	
if ( $email!="" )
{
  if ($email=="admin@sito.com")
	  echo "Benvenuto Boss!".$nl;
}
else		
  echo "Email mancante".$nl;
		

if ("001" !== 1)
  echo "Vero";
else
  echo "Falso "




		
		

	
?>

</body>
</html>







<!--

if ("0")
	  echo "VERO! $nl";
	else
	  echo "FALSO! $nl";
	$secure = $_POST['secure'];

-->