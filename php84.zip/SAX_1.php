<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
	<title>XPATH</title>
</head>

<body>

<?php
function trattini($nl="<br />")
{
			echo "-------------------------------------$nl";					
}


//HANDLERS per il parser

// richiamato quando viene riconosciuta l'apertura di un elemento (tag)
// quello che interessa fare di solito e' elaborare gli
//eventuali attributi
function apertura_elemento($parser, $nome_elemento, $attributi)
{
  if( !empty($nome_elemento) )
		{
     echo "aperto " . $nome_elemento . "<br />";
					
					if( count($attributi) )
       foreach($attributi as $nome_attributo => $attributo)
							  echo $nome_attributo . ": " . $attributi[$nome_attributo] . "<br />"; 
  }
}

function dati_elemento($parser, $dati)
{  
  echo "contenuto: " . $dati . "<br />";
}

function chiusura_elemento($parser, $nome_elemento)
{
  echo "chiuso " . $nome_elemento . "<br />";
}

?>


<?php
	$nl = "<br />";

 //creiamo un nuovo parser SAX; il costruttore restituisce il riferimento al parser 
	//che sar� passato come parametro alle altre funzioni
	$parser = xml_parser_create(); 
   
 //registriamo le funzioni che saranno automaticamente invocate dal parser
	//ogni volta che quest'ultimo incontrer� l'apertura e la chiusura
	//di un nuovo elemento (tag)
	xml_set_element_handler($parser, "apertura_elemento", "chiusura_elemento");
	xml_set_character_data_handler($parser, "dati_elemento");
	
 // tentiamo di aprire il file XCML
 if ( !($handle = fopen('libri.xml', "r")) ) 
   die("Impossibile aprire il file XML");
  
 //passiamo al parser blocchi del file di 4096 byte per volta
 while($data = fread($handle, 4096)) 
   xml_parse($parser, $data);  
   
 //rilasciamo le risorse occupate dal parse
	xml_parser_free($parser); 
   
	
?>


</body>
</html>
