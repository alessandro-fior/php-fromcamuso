<?php
session_start();
require_once __DIR__ . '/src/Facebook/autoload.php';

 $facebook = new Facebook\Facebook(array(
  'app_id'  => '188828681575995',
  'app_secret' => 'xxxxxxxxxxxxxxxxx'
 ));
 
$helper = $facebook->getRedirectLoginHelper();

$concedi_uso_di= ['email']; // opzionale
$login_url = $helper->getLoginUrl('http://localhost/yt/security/index.php', $concedi_uso_di);
echo "URL GENERATO:</br> " .$login_url."</br></br>";

echo "<a href='" . htmlspecialchars($login_url) . "'>Login con Facebook</a>"; 
?>