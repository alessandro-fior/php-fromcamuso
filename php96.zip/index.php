<?php
session_start();
require_once __DIR__ . '/src/Facebook/autoload.php';

$facebook = new Facebook\Facebook([
  'app_id' => '188828681575995', 
  'app_secret' => 'xxxxxxxxxxxxxxxxxxxxxxx'
  ]);

$helper = $facebook->getRedirectLoginHelper();

try
{
  $accessToken = $helper->getAccessToken();
}
//errore graph api
catch(Facebook\Exceptions\FacebookResponseException $e)
{
  echo 'La Graph API ha restituito questo errore: ' . $e->getMessage();
  exit;
}
//errore di validazione o altro legato all'SDK
catch(Facebook\Exceptions\FacebookSDKException $e)
{
  echo 'Facebook SDK ha restituito questo errore: ' . $e->getMessage();
  exit;
}

if (! isset($accessToken)) {
  if ($helper->getError()) {
    header('HTTP/1.0 401 Unauthorized');
    echo "Errore: " . $helper->getError() . "\n";
    echo "Codice errore: " . $helper->getErrorCode() . "\n";
    echo "Causa dell'errore: " . $helper->getErrorReason() . "\n";
    echo "Descrizione estesa dell'errore: " . $helper->getErrorDescription() . "\n";
  } else {
    header('HTTP/1.0 400 Bad Request');
    echo 'Bad request';
  }
  exit;
}

// Login effettuato con successo
echo '<h3>Token (gettone) di accesso</h3>';
var_dump($accessToken->getValue());

// per gestire il token di accesso ...
$oAuth2Client = $facebook->getOAuth2Client();

// Acceso ai metadati del token
$tokenMetadata = $oAuth2Client->debugToken($accessToken);
echo '<h3>Metadati</h3>';
var_dump($tokenMetadata);

// Convalida (throw di FacebookSDKException in caso di fallimento)
$tokenMetadata->validateAppId('188828681575995');

//(traduzione dall'esempio dal sito di facebook/developers)
//Nel caso si conosca lo user ID corrispondente al token potete validarlo
//cos�:
//$tokenMetadata->validateUserId('123');
$tokenMetadata->validateExpiration();

if (! $accessToken->isLongLived()) {
  // Sostituzione di un token a breve durata con uno a lunga
  try {
    $accessToken = $oAuth2Client->getLongLivedAccessToken($accessToken);
  } catch (Facebook\Exceptions\FacebookSDKException $e) {
    echo "<p>Errore nel tentativo di ottenere un gettone a lunga durata: " . $helper->getMessage() . "</p>\n\n";
    exit;
  }

  echo '<h3>Gettone a lunga durata</h3>';
  var_dump($accessToken->getValue());
}

//rendiamo disponibile il token fino alla chiusura della session (per altre pagine)
$_SESSION['fb_access_token'] = (string) $accessToken;

// L'utente ha effettuato il login con un token duraturo
// Di solito si reindirizza a questo punto alla pagina radice per gli utenti autenticati
//header('Location: https://example.com/members.php'); 

//logout
$logout_url = $helper->getLogoutUrl($accessToken,'http://localhost/yt/security/login.php');
echo "</br><a href='" . htmlspecialchars($logout_url) . "'>LOGOUT</a>";
//ovviamente se il logout fosse su un'altra pagina l� dovremmo prima
//creare un oggetto Facebook per accedere all'helper esattamente come su questa...
?>






