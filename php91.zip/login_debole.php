<?php
  include("gestione_sessioni.inc");
		
		if($_SERVER["HTTPS"] != "on")
		{
    die('Login consentito solo via HTTPS');
  }
		
  session_start();
		
 if( isset($_GET['password']) && $_GET['password'] == 'psw_vittima' ) {
	$_SESSION['logged_in'] = true;
	$_SESSION['logged_in_as'] = 'Signor pollo...';
	
}

if( isset($_SESSION['logged_in']) && $_SESSION['logged_in'] )
{
  echo "Collegato come ", $_SESSION['logged_in_as'];
		session_regenerate_id();
		
  $_SESSION=array();
  $_SESSION['logged_in_as'] = 'Signor pollo...';		
}
else
{
  echo "Autenticazione Fallita";
}

echo "<br>", "Il tuo id di sessione e': " . session_id(); 

?>

