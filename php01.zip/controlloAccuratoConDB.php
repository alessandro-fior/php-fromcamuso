<?php
  
  //NOTA BENE
  //puoi trovare i commenti dettagliati sulle funzioni, qui di seguito usate, 
  //nel codice della pagin controlloSempliceConDB.php che trovi in questa stessa
  //cartella

  //a differenza della pagina controlloSempliceConDB.php si verifica l'esito
  //delle operazioni tentate; 
    
  //raccolgo i dati dalla form
  $user = $_REQUEST["user"];
  $psw = $_REQUEST["psw"];
  
  //restituisce true/false
  $conn = mysql_connect("localhost", "root", "");
  
  if (!$conn)
  {
    mysql_close($conn); 
    die("Problemi nello stabilire la connessione");
  }	
  
  if (!mysql_select_db("utenti"))
  {
    mysql_close($conn); 
    die("Errore di accesso al data base utenti");
  }
  
  $comando = "select psw from accesso where userName='" . $user . "'";
  $risultato =  mysql_query($comando);
	   
  if (!$risultato)
  {
    mysql_close($conn); 
    die("Errore nell'esecuzione della query: " . $comando); 
  }
  
  $riga = mysql_fetch_assoc($risultato);
  
  //chiudo la connessione
  mysql_close($conn); 

  //$riga contiene allora i dati richiesti con il comando sql: � la psw che
  //provvedo a confrontare con quella inserita sulla form e recuperata nella
  //variabili $psw all'inizio di questa pagina
  //se il controllo viene superato reindirizzo alla pagina 'welcome.htm'
  //altrimenti alla pagina 'rifiuto.htm'
    if ($riga["psw"] == $psw)
	   header("Location: welcome.htm");
	else
	   header("Location: rifiuto.htm");
 
?>

