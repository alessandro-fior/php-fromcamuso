<?php
  
  //NOTA: per far funzionare bene redirect nella parte finale questa pagina
  //      contiene solo codice PHP e niente altro
  
  // IN QUESTA VERSIONE DEL CONTROLLO D'ACCESSO NON HO MAI CONTROLLATO
  // PER SEMPLICITA' I RISULTATI DEI VARI COMANDI; QUINDI NON HO INTERCETTATO
  //ERRORI COME UNA CONNESSIONE FALLITA, UN ERRORE NELLA STRINGA SQL O ASSENZA
  //DI RIGHE RESTITUITE DAI COMANDI ECC.
  //IN QUESTA STESSA CARTELLA ESISTE UNA VERSIONE (controlloAccuratoConDB) CHE 
  //INVECE SI PREOCCUPA DI TUTTO QUESTO
   
  //raccolgo i dati dalla form (sulla pagina che ha richiamato questa e che 
  //ha raccolto i dati inseriti)
  $user = $_REQUEST["user"];
  $psw = $_REQUEST["psw"];
  
  //connessione a MySql; 
  //  restituisce: 
  //    false in caso di fallimento
  //    un oggetto connessione, da usare in seguito, in caso di successo
  
  // 3 parametri
  //   1. indirizzo del server mysql (localhost=quello locale sul PC)
  //   2. nome utente da usare: l'installazione di XAMPP imposta l'utente 
  //      'root' privo di password; si pu� impostare la password e creare altri
  //      utenti con privilegi differenziati
  //   3. password (vedi il punto precedente)

  //Nota Bene
  //qui di seguito per brevit�/semplicit� non controllo l'esito dell'operazione
  //in questa stessa cartella esistone una versione di questa pagina
  //che fa tutti controlli del caso (controlliAcccurati.php 
  $conn = mysql_connect("localhost", "root", "");
  
  //la connessione apre la strada all'uso di tutti i database gestiti da MySql
  //devo scegliere quale usare
  //la prossima funzione restituisce true se successo, false se fallimento
  //ma per brevit�/semplicit� non controllo l'esito dell'operazione
  mysql_select_db("utenti");
  
  //a questo punto possiamo inviare comandi SQL al database
  // chiedo la password (select psw)   
  // dalla tabella accesso (from accesso)
  // di quell'utente il cui username ('where userName=' dove userName � il nome del 
  // campo, della tabella, contenente lo user name) � uguale a quanto digitato 
  // nel textbox chiamato user sulla form, valore che abbiamo recuperato 
  // all'inizio di questa pagina con $user = $_REQUEST["user"];
  // il valore deve essere racchiuso tra apici '
  // esempio: se l'utente si chiamasse diabolik il comando sarebbe:
  //          select psw from utenti where userName = 'diabolik'
  // qui sotto si costruisce esattamente questa stringa concatenando con l'operatore
  // . (punto) tre parti:
  // a) select psw from utenti where userName='  notare l'apice di apertura
  // b) $user
  // c) '  l'apice finale!
  $comando = "select psw from accesso where userName='$user'";
  
  
  //invio il comando (query)
  // la funzione usata restituisce false (ma di nuovo non si fanno controlli)
  // in caso di insuccesso; altrimenti un riferimento da usare successivamente
  // per recuperare tutti i record che soddisfano la condizione 'where' usata
  // prima (che dovrebbe essere uno solo poich� non sono ammessi utenti con 
  // lo stesso user name) 

  // Nota Bene: per insuccesso non si intende che non ha trovato neanche un
  // record! Ma che, ad esempio, il comando sql contiene un errore di sintassi
  // o che nel frattempo la connessione con mysql si � interrotta o il server
  // non � disponibile a rispondere ecc. 
  $risultato = mysql_query($comando);
  
 
  //usando il riferimento ($risultato) posso attingere (mysql_fetch_assoc) ai 
  //record che vengono restituiti, uno alla volta: uno per ogni invocazione del 
  //comando mysql_fetch_assoc; questo comando restituisce infatti un vettore
  //in cui ogni elemento corrisponde ad un campo del record; il vettore �
  //di tipo associativo: invece di usare una posizione numerica si indicher� tra
  //parentesi quadre il nome del campo come stringa. 

  // Nota Bene: quando non ci sono pi� record mysql_fetch_assoc restituisce false; 
  $riga = mysql_fetch_assoc($risultato);

  
   //chiudo la connessione
   mysql_close($conn); 

  //$riga contiene allora i dati richiesti con il comando sql: � la psw che
  //provvedo a confrontare con quella inserita sulla form e recuperata nella
  //variabili $psw all'inizio di questa pagina
  //se il controllo viene superato reindirizzo alla pagina 'welcome.htm'
  //altrimenti alla pagina 'rifiuto.htm'
    if ($riga["psw"] == $psw)
	  header("Location: welcome.htm");
	else
	   header("Location: rifiuto.htm");
	
  
?>


