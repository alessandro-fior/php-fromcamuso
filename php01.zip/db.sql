-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generato il: 23 mar, 2010 at 09:50 
-- Versione MySQL: 5.1.41
-- Versione PHP: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `utenti`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `accesso`
--

CREATE TABLE IF NOT EXISTS `accesso` (
  `idUtente` int(11) NOT NULL AUTO_INCREMENT,
  `cognome` varchar(25) NOT NULL,
  `nome` varchar(25) NOT NULL,
  `userName` varchar(12) NOT NULL,
  `psw` varchar(12) NOT NULL,
  PRIMARY KEY (`idUtente`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dump dei dati per la tabella `accesso`
--

INSERT INTO `accesso` (`idUtente`, `cognome`, `nome`, `userName`, `psw`) VALUES
(1, 'rossi', 'mario', 'rexx', 'kdlfjk'),
(2, 'verdi', 'sandro', 'james bond', '007007');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
