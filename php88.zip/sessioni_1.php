<?php
 include("gestione_sessioni.inc");
	
 session_start();
	$_SESSION['id_critico'] = "xyzQW";
	$_SESSION['id_critico2'] = "xyzQW2";
	
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
	<title>Untitled</title>
</head>

<body>
 <a href="sessioni_2.php"> clic </a><br />
</body>
</html>
