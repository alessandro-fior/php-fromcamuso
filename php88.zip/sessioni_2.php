<?php
 include("gestione_sessioni.inc");
 session_start();
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
	<title>Untitled</title>
</head>

<body>
PAGINA 2...<br />
<?php
  if ( isset($_SESSION["id_critico"]) && $_SESSION["id_critico"] === "xyzQW" )
  		die("ERRORE CRITICO ... shutting down system ...");

		//altrimenti procediamo		
		//... resto del codice		
?>

</body>
</html>
