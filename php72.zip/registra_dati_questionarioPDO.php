<?php
	 include($_SERVER['DOCUMENT_ROOT']."\..\my_include\setup.php");
		
		if (  !isset($_SESSION['iduser']) )
		{
		  header("Location: login.php?errore=autenticazione_richiesta"); //user non autenticato
				exit;
		}

  //recupero credenziali da file ESTERNO alla cartella pubblica del sito
  $accessData=parse_ini_file('..\..\..\my_ini\configDB.ini');
		
				try 
				{
      //CONNESSIONE
      $conn = new PDO("mysql:host=localhost;dbname={$accessData['dbname']}",
																		$accessData['username'],$accessData['password']); 
				}
				
		  catch (PDOException $e)
		  {
      echo $e->getMessage() . "<br/>";
				  echo "Connessione al server fallita. Impossibile procedere. Contattare ...";
      die();
		  }								
  
  //ATTIVAZIONE ECCEZIONI PER METODO QUERY 
		$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		  
		//prima inseriamo la riga del questionario nella tabella questionari
		$data_oggi = date("Y-m-d");
		$comandoSQL = "insert into questionari values (null, " .
		  $conn->quote($_POST['descrizione']) . ", " .
				"'" . $data_oggi . "', " .
				"'" . $_SESSION['iduser'] . "')";				
		
	
  try
		{
  		$conn->query($comandoSQL);			
		}
		
		catch (PDOException $e)
		{
    echo $e->getMessage() . "<br/>";
				echo "Inserimento fallito ...";
				
    die();
		}

		$idQuestionario = $conn->lastInsertId();
		
		//PREPARED STATEMENTS
 	
			//$comando_prepared =
		  //$conn->prepare("insert into items values (null, ?, ?)");
		
		$comando_prepared =
		  $conn->prepare("insert into items values (null, :fkQuestionario, :fkDomanda)");
																					
  //binding segnaposto ? con rispettive variabili 
		//$comando_prepared->bindParam(1, $fkQuestionario, PDO::PARAM_INT);
		//$comando_prepared->bindParam(2, $fkDomanda, PDO::PARAM_INT);

		$comando_prepared->bindParam(':fkQuestionario', $fkQuestionario , PDO::PARAM_INT);
		$comando_prepared->bindParam(':fkDomanda', $fkDomanda, PDO::PARAM_INT);
		
		
		//recuperiamo le domande scelte sulla form
		$domande = $_POST['domande_scelte'];
		for($i=0; $i<count($domande); $i++)
  {
				$fkQuestionario=$idQuestionario;
				$fkDomanda=$domande[$i];
				
				try
				{
				   $comando_prepared->execute();
				}
	  
 			catch (PDOException $e)
	 	 {
     echo $e->getMessage() . "<br/>";
			 	echo "Inserimento fallito ...";
					
					try				
					{
 						//allora eliminiamo il questionario
	 				 $conn->query("delete from questionari where idquestionario=$idQuestionario");
					}

		   catch (PDOException $e)
	 	  {
      echo $e->getMessage() . "<br/>";
			 	 echo "Impossibile eliminare ...";
				  }

     die();
		  }				
		 }
		

 //CHIUDIAMO LA CONNESSIONE E LIBERIAMO LE RISORSE OCCUPATE ...
		$conn=null;






















/*  if ($esito)
    $idQuestionario = mysqli_insert_id( $conn );
  else
  {
    mysqli_close($conn);
    header("Location: login.php?errore=inserimento_fallito"); //inserimento fallito
  }				
		
		//per gli N insert into per la tabella degli items conviene usare
		//i prepared statement
		$comando_prepared =
		  mysqli_prepare($conn, "insert into items values (null, ?, ?)");
																			
		//i=intero, d=double, s=stringa
		mysqli_stmt_bind_param($comando_prepared, "ii", $fkQuestionario, $fkDomanda);
		
		$domande = $_POST['domande_scelte'];
		for($i=0; $i<count($domande); $i++)
  {
				$fkQuestionario=$idQuestionario;
				$fkDomanda=$domande[$i];
				mysqli_stmt_execute($comando_prepared);
		}
		
		mysqli_stmt_close($comando_prepared);
	 mysqli_close($conn);
	 */
?>


