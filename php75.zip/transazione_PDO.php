<?php
	 include($_SERVER['DOCUMENT_ROOT']."\..\my_include\setup.php");
	
  //recupero credenziali da file ESTERNO alla cartella pubblica del sito
  $accessData=parse_ini_file('..\..\..\my_ini\configDB.ini');
		
				try 
				{
      //CONNESSIONE
      $conn = new PDO("mysql:host=localhost;dbname={$accessData['dbname']}",
																		$accessData['username'],$accessData['password']); 
				}
				
		  catch (PDOException $e)
		  {
      echo $e->getMessage() . "<br/>";
				  echo "Connessione al server fallita. Impossibile procedere. Contattare ...";
      die();
		  }								
  
  //ATTIVAZIONE ECCEZIONI PER METODO QUERY 
		$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		  			
  try
		{
  		$conn->beginTransaction();
				
				$comandoSQL ="delete from questionari_svolti where fine<'2002-01-01'";
				$conn->exec($comandoSQL);
								
				//dopo l'esecuzione del precedente comando e quella del seguente
				//potrebbere verificarsi una anomalia che blocca l'esecuzione
				//sul server ...
				
				//verrebbe sollevata l'eccezione, saltato il commit e comandato il rollback
							
	   //controlli ...
/*				$errore=true;
				if($errore)
				  $conn->rollBack(); //annulliamo le operazioni precedenti
    else				
				{
				  $comandoSQL = "delete from users where iduser not in ".
				              "(select fkuser from questionari_svolti)";
				  $conn->exec($comandoSQL);
				
		    //se siamo arrivati qui rendiamo permanenti le modifiche
				  $conn->commit();
				}
*/

			  $comandoSQL = "delete from users where iduser not in ".
				              "(select fkuser from questionari_svolti)";
				 $conn->exec($comandoSQL);
				
		   //se siamo arrivati qui rendiamo permanenti le modifiche
				 $conn->commit();


		}
		
		catch (Exception $e)
		{
    $conn->rollBack();
				echo "Pulizia archivi fallita ".$nl;
				
    die();
		}
	

 //CHIUDIAMO LA CONNESSIONE E LIBERIAMO LE RISORSE OCCUPATE ...
		$conn=null;






















/*  if ($esito)
    $idQuestionario = mysqli_insert_id( $conn );
  else
  {
    mysqli_close($conn);
    header("Location: login.php?errore=inserimento_fallito"); //inserimento fallito
  }				
		
		//per gli N insert into per la tabella degli items conviene usare
		//i prepared statement
		$comando_prepared =
		  mysqli_prepare($conn, "insert into items values (null, ?, ?)");
																			
		//i=intero, d=double, s=stringa
		mysqli_stmt_bind_param($comando_prepared, "ii", $fkQuestionario, $fkDomanda);
		
		$domande = $_POST['domande_scelte'];
		for($i=0; $i<count($domande); $i++)
  {
				$fkQuestionario=$idQuestionario;
				$fkDomanda=$domande[$i];
				mysqli_stmt_execute($comando_prepared);
		}
		
		mysqli_stmt_close($comando_prepared);
	 mysqli_close($conn);
	 */
?>


