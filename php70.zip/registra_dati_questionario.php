<?php
	 include($_SERVER['DOCUMENT_ROOT']."\..\my_include\setup.php");
		
		if (  !isset($_SESSION['iduser']) )
		{
		  header("Location: login.php?errore=autenticazione_richiesta"); //user non autenticato
				exit;
		}

  //recupero credenziali da file ESTERNO alla cartella pubblica del sito
  $accessData=parse_ini_file('..\..\..\my_ini\configDB.ini');
		
		//connessione e selezione db
		$conn = @mysqli_connect("localhost",$accessData['username'],$accessData['password']);  
				
		if(!$conn)
  { echo "Connessione al server fallita. Impossibile procedere. Contattare ...";
    die;  
  }
  
		if ( !@mysqli_select_db($conn, $accessData['dbname']) )
  {
    echo "Non trovo il data base ...";
    die;       
  }

		//prima inseriamo la riga del questionario nella tabella questionari
		$data_oggi = date("Y-m-d");
		$comandoSQL = "insert into questionari values (null, " .
		  "'" . mysqli_escape_string($conn, $_POST['descrizione']) . "', " .
				"'" . $data_oggi . "', " .
				"'" . $_SESSION['iduser'] . "')";
		
		$esito = mysqli_query($conn, $comandoSQL);

  if ($esito)
    $idQuestionario = mysqli_insert_id( $conn );
  else
  {
    mysqli_close($conn);
    header("Location: login.php?errore=inserimento_fallito"); //inserimento fallito
  }				
		
		//per gli N insert into per la tabella degli items conviene usare
		//i prepared statement
		$comando_prepared =
		  mysqli_prepare($conn, "insert into items values (null, ?, ?)");
																			
		//i=intero, d=double, s=stringa
		mysqli_stmt_bind_param($comando_prepared, "ii", $fkQuestionario, $fkDomanda);
		
		$domande = $_POST['domande_scelte'];
		for($i=0; $i<count($domande); $i++)
  {
				$fkQuestionario=$idQuestionario;
				$fkDomanda=$domande[$i];
				mysqli_stmt_execute($comando_prepared);
		}
		
		mysqli_stmt_close($comando_prepared);
	 mysqli_close($conn);
?>


