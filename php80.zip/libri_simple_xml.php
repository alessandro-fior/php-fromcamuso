<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
	<title>Untitled</title>
</head>

<body>
<?php
function stampa_XML($documento)
{
  foreach($documento->libro as $libro)
    echo "Autore $libro->isbn $libro->autore $libro->titolo <br />";
}

function stampa_XML_con_attributi($documento)
{
  echo $documento['genere']."<br />";
		
		foreach($documento->libro as $libro)
		{
			 echo "Autore $libro->isbn $libro->autore $libro->titolo <br />";
				echo "Stelle: ".$libro['stelle']."<br />";
		  echo "------------------------------------------<br />";
		}
}

?>

<?php
  $documento = simplexml_load_file("libri.xml");

		//aggiungere un attributo (al livello piu' esterno, di 'biblioteca')
		$documento->addAttribute("genere","fantascienza");
		
  //aggiungere un attributo ad ogni libro
  foreach($documento->libro as $libro)
		  $libro->addAttribute("stelle",rand(1,5));

  //aggiungere un nuovo nodo al livello principale
		//cioe' un nuovo libro
		$nuovo_libro = $documento->addChild('libro');
  
		//con il riferimento al libro aggiungiamo al suo interno l'isbn
		$nuovo_libro->addChild('isbn', '9999999');
		
		//... e l'elenco dei suoi autori
  $autori = $nuovo_libro->addChild('elenco_autori');
		
		//e al suo interno tre nuovi nodi autore
		$autori->addChild('autore', 'nuovoAutore1');
		$autori->addChild('autore', 'nuovoAutore2');
		
		//infine il titolo
		$nuovo_libro->addChild('titolo', 'nuovo_libro');
		
		
		//aggiorna il file
		$documento->asXML("libri.xml");
	
		stampa_XML($documento);
		
		
		stampa_XML_con_attributi($documento);
  echo "================================== <br />";

?>


</body>
</html>
