<?php
 $immagine = imagecreatefromjpeg("..\img\micio.jpg");
	$grigio = imagecolorallocate($immagine, -0x44, -0x44, -0x44);
	
	
	$logo = imagecreatefrompng("..\img\puntoDomanda.png");
	$larghezza_logo = imagesx($logo);
	$altezza_logo = imagesy($logo);
	


	//'scriviamo' sull'immagine
	
	//2 = font predefinito numero 2
	//cene sono 5: 1 = pi� piccolo, ..., 5=pi� grande
	//imagestring($immagine, 2, 5, 50, "CatFactory - 2016", $grigio);
	
	
	putenv("GDFONTPATH=" . realpath('.') );
// imagettftext($immagine, 10,45, 10, 65, $grigio,
//														'UnmaskedBB.ttf', "CatFactory&#169;");
 
	//sovraimposizione di un'altra immagine
 imagecopyresampled($immagine, $logo,  //destinazione e sorgente
											0, 0,  //coordinate rettangolo destinazione
											0, 0,  //coordinate rettangolo sorgente
											$larghezza_logo/2, $altezza_logo/2, //dimensioni rettangolo destinazione
											$larghezza_logo, $altezza_logo); //dimensioni rettangolo sorgente
	
	header("Content-Type: image/png");
 imagepng($immagine);
?>
