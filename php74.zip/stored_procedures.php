<html>
<head>
    <title>Esempio con le stored procedure</title>  
</head>

<body>
 
<?php
	 include($_SERVER['DOCUMENT_ROOT']."\..\my_include\setup.php");
		
  //recupero credenziali da file ESTERNO alla cartella pubblica del sito
  $accessData=parse_ini_file('..\..\..\my_ini\configDB.ini');
		
				try 
				{
      //CONNESSIONE
      $conn_pdo = new PDO("mysql:host=localhost;dbname={$accessData['dbname']}",
																		$accessData['username'],$accessData['password']); 
				}
				
		  catch (PDOException $e)
		  {
      echo $e->getMessage() . "<br/>";
				  echo "Connessione al server fallita. Impossibile procedere. Contattare ...";
      die();
		  }								
  
  //ATTIVAZIONE ECCEZIONI PER METODO QUERY 
		$conn_pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);	  
	
	 $soglia=1;
		$comandoSQL = "call domande_per_argomento($soglia)";
		
  try
		{
  		$risultato = $conn_pdo->query($comandoSQL);			
		}
		
		catch (PDOException $e)
		{
    echo $e->getMessage() . "<br/>";
				echo "Nessun risultato ottenuto  ...";
				
    die();
		}

	//fetch mode di default: PDO::FETCH_BOTH (associativo e per n. colonna)
	while ( $riga = $risultato->fetch() )
	{
		 //usando i nomi delle colonne restituite
			echo $riga['argomento'].": ".$riga['numero_domande'].$nl;
	}
 echo "-------------------------------".$nl;
	
	$risultato->closeCursor();
	
	$comando_prepared = $conn_pdo->prepare("call punteggio_medio(@ris)");
	$comando_prepared->execute();

	$comando_prepared->closeCursor();
	
	$risultato = $conn_pdo->query("select @ris");
	$riga = $risultato->fetch();
	echo "Punteggio medio per domanda: " . $riga['@ris'];

	
 //CHIUDIAMO LA CONNESSIONE E LIBERIAMO LE RISORSE OCCUPATE ...
		$conn=null;

?>


</body>
</html>