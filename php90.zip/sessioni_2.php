<?php
 include("gestione_sessioni.inc");
 session_start();
	
	echo "DATI SESSIONE: <br />";
	echo $_SESSION['id_critico1'] . " - " . $_SESSION['id_critico2'];
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
	<title>Untitled</title>
</head>

<body>
PAGINA 2...<br />
<?php
  if ( isset($_SESSION["id_critico1"]) && $_SESSION["id_critico1"] === "xyzQW1" )
  		die("ERRORE CRITICO ... shutting down system ...");

		//altrimenti procediamo		
		//... resto del codice		
?>

</body>
</html>
