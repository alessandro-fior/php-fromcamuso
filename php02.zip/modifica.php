<?php session_start(); ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">

<html>
<head>
  <title>Modifica utente</title>
</head>

<body>
<?php
 
$conn = mysql_connect("localhost", "root", "") or die("Problemi nello stabilire la connessione");
mysql_select_db("utenti") or die("Errore di accesso al data base utenti");

 	
  //recupero il codice utente dalla query string nell'indirizzo (?idutente=...)
  //poich� servir� anche alla pagina, action di questa form, che effettuer�
  //la registrazione sul db, memorizzo questo valore in una VARIABILE di 
  //SESSIONE recuperabile su TUTTE le pagine durante la navigazione fino
  //all'abbandono del sito
  $_SESSION['idUtente'] = $_REQUEST[idUtente];
 
  //leggo dal db i dati dell'utente
  $comando = "select * from utenti_registrati where idUtente='$_REQUEST[idUtente]'";
  $result = mysql_query($comando);

  echo "$comando <br />";
  $dati = mysql_fetch_assoc($result);
  
  $cognome = $dati["cognome"];
  $nome = $dati["nome"];
  $ksComune = $dati["ksComune"];
  $userName = $dati["userName"];
  $psw = $dati["psw"];
 
?>

  <form  method="post" name="registra" action="eModifica.php" id="registra">
    <table>
      <tbody>
        <tr>
          <td>Cognome</td>

          <td><input type="text" id="cognome" name="cognome" value='<?php echo $cognome ?>'  ></td>
        </tr>

        <tr>
          <td>Nome</td>

          <td><input type="text" id="nome" name="nome" value='<?php echo $nome ?>'></td>
        </tr>
		
		<tr>
		<td> Comune </td>
		<td>
		  <select name="elencoComuni">
		    
		  <?php
		    
				//preparo elenco comuni
				$comando = "select * from comuni";
				$result = mysql_query($comando);
				
				while ($dati = mysql_fetch_assoc($result))
  	   		{
 			      echo "<option value='$dati[idComune]' ";
						if ($dati[idComune]==$ksComune) echo "selected";
						echo"> $dati[nomeComune] </option>\n";
			    }
		    mysql_close();
				
		  ?>
		  
         		  
		  </select>
		
		</td>
		
		</tr>

        <tr>
          <td>User Name</td>

          <td><input type="text" id="user" name="user" value='<?php echo $userName ?>'></td>
        </tr>

        <tr>
          <td>Password</td>

          <td><input id="psw" type="password" name="psw" value='<?php echo $psw ?>'> </td>
        </tr>

      </tbody>
    </table> <br>
 
    <input id="aggiorna" value="AGGIORNA" type="submit" name="aggiorna">
  </form>
</body>
</html>
