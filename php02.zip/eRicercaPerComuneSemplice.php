<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">

<html>
<head>
  <title>Registrazione nuovo utente</title>
 </head>

<body>
<?php
  
     
  //raccolgo i dati dalla form
  $idComune = $_REQUEST["elencoComuni"];
	
  $conn = mysql_connect("localhost", "root", "") or die("Problemi nello stabilire la connessione");
  mysql_select_db("utenti") or die("Errore di accesso al data base utenti");  
 
  $result = mysql_query("select * from utenti_registrati, comuni where idComune=ksComune and ksComune = '$idComune'");
 
  echo "<table border='1'>\n";
  
  //intestazioni
   echo "<tr style='font-weight:bold; color:blue;'>",
	   "<td>  </td> <td> </td><td> idUtente </td> <td> cognome </td> ",
	   "<td> nome </td> <td> userName </td> <td> psw </td> <td> Nome Comune </td>",
	" </tr> \n";
  
 
  //righe con i dati
    while ( $dati = mysql_fetch_assoc($result) ) 
    {
 	  echo "<tr>\n";
	  echo "<td> <a href='modifica.php?idUtente=$dati[idUtente]'> Modifica </a>  </td>\n";
	  echo "<td> <a href='elimina.php?idUtente=$dati[idUtente]'> Elimina </a>  </td>\n";

    echo "<td> $dati[idUtente] </td>\n";
  	echo "<td> $dati[cognome] </td>\n";
  	echo "<td> $dati[nome] </td>\n";
  	echo "<td> $dati[userName] </td>\n";
	  echo "<td> $dati[psw] </td>\n";
  	echo "<td> $dati[nomeComune] </td>\n";


      echo "</tr> \n";
    }
 

 echo "</table>\n";
 
  //chiudo la connessione
  mysql_close($conn); 

  echo "<br /> <a href='index.html'> Torna al menu </a>";
 
?>
</body>
</html>

