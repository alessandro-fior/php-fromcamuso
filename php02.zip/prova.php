<?php
 $eta=18;
 eta>18 ? print("maggiorenne") : print("minorenne");
 //eta>18 ? 1000 : -1000;
?>