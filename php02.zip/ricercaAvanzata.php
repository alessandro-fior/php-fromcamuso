<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">

<html>
<head>
  <title>Ricerca</title>
</head>

<body>
  <form  method="post" name="scegli" action="eRicercaAvanzata.php" id="scegli">
    <table>
        <tr>
          <td>Cognome</td>

          <td><input id="cognome" name="cognome"></td>
        </tr>

        <tr>
          <td>Nome</td>

          <td><input id="nome" name="nome"></td>
        </tr>
		
		<tr>
		<td> Comune </td>
		<td>
		  <select name="elencoComuni">
		  <option value="" selected> non definito </option>
		    
		  <?php
        $conn = mysql_connect("localhost", "root", "") or die("Problemi nello stabilire la connessione");
				mysql_select_db("utenti") or die("Errore di accesso al data base utenti");
 					  
				$comando = "select * from comuni";
			  $result = mysql_query($comando);
			
		    while ($dati = mysql_fetch_assoc($result))
  	   		 print "<option value='$dati[idComune]'> $dati[nomeComune] </option>";
		  ?>
		  
		  
		  </select>
		
		</td>
		
		</tr>

        <tr>
          <td>User Name</td>

          <td><input id="user" name="user"></td>
        </tr>

       </table> <br>
 
    <input id="cerca" value="CERCA" type="submit" name="cerca">
  </form>
</body>
</html>
