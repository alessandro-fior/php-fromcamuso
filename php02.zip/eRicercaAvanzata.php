<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">

<html>
<head>
  <title>Registrazione nuovo utente</title>
  <meta name="GENERATOR" content="Evrsoft First Page">
</head>

<body>
<?php
  
     
  //raccolgo i dati dalla form
  $cognome = $_REQUEST["cognome"];
  $nome = $_REQUEST["nome"];
  $ksComune = $_REQUEST["elencoComuni"];
  $userName = $_REQUEST["user"];
  $psw = $_REQUEST["psw"];
  
  //restituisce true/false
  $conn = mysql_connect("localhost", "root", "");
  
  if (!$conn)
  {
    mysql_close($conn); 
    die("Problemi nello stabilire la connessione");
  }	
  
  if (!mysql_select_db("utenti"))
  {
    mysql_close($conn); 
    die("Errore di accesso al data base utenti");
  }
 					  
  $comando = "select idUtente,cognome, nome, userName, " .
             "psw, nomeComune from comuni, utenti_registrati where idComune=ksComune ";
  
  if ($cognome)
    $comando = $comando . "and cognome like '%$cognome%' ";
  	 
  if ($nome)
    $comando =  $comando . "and nome like '%$nome%' ";

  if ($ksComune)
    $comando = $comando . "and ksComune='$ksComune' ";
  
  if ($userName)
    $comando = $comando . "and userName like '%$userName%' ";
	
  echo "Comando: " .$comando . "<br>";
  
  $result = mysql_query($comando);
 
  echo "<table border='1'>\n";
  
  //intestazioni
   echo "<tr style='font-weight:bold; color:blue;'>",
	   "<td>  </td> <td> </td><td> idUtente </td> <td> cognome </td> ",
	   "<td> nome </td> <td> userName </td> <td> psw </td> <td> Nome Comune </td>",
	" </tr> \n";
  
 
  //righe con i dati
  if ($result)
    while ( $dati = mysql_fetch_assoc($result) ) 
    {
 	  echo "<tr>";
	  echo "<td> <a href='modifica.php?idUtente=$dati[idUtente]'> Modifica </a>  </td>";
	  echo "<td> <a href='elimina.php?idUtente=$dati[idUtente]'> Elimina </a>  </td>";

  	  print "<td> $dati[idUtente] </td>";
  	  print "<td> $dati[cognome] </td>";
  	  print "<td> $dati[nome] </td>";
  	  print "<td> $dati[userName] </td>";
	  print "<td> $dati[psw] </td>";
  	  print "<td> $dati[nomeComune] </td>";


      echo "</tr> \n";
    }  

 echo "</table>\n";
 
  //chiudo la connessione
  mysql_close($conn); 

  print "<br /> <a href='ricerca.php'> Nuova Ricerca </a>";
 
?>
</body>
</html>

