<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">

<html>
<head>
  <title>Ricerca</title>

<script>
 //usa il campo di input 'cognome' per copiare nel campo nascosto la stringa
 //sql da inviare alla pagina indicata nella action
 //NOTA: non si pu� fare la stessa cosa con una variabile di sessione passata direttamente
 //      alla pagina eRicerca perche' l'inserimento del cognome e' fatto sul client e con
 //      javascript non e' fisicamente possibile accedere alle variabili di sessione,
 //      per loro natura gestite dal server
 function costruisciStringaSQL()
 {
	  document.getElementById("comandoSQL").value =
		"select * from comuni, utenti_registrati where idComune=ksComune and cognome like '%" +
		document.getElementById("cognome").value + "%'";
 }
</script>
  </head>

<!--Cio' che viene scritto nella casella del cognome viene usato per compilare il comando
sql usato dalla pagina richiamata nella action per interrogare mysql; in questo modo
potremo avere tanti schemi di ricerca diversi ma sempre la stessa pagina che presenta
i risultati della ricerca.

La stringa del comando viene posta in un campo nascosto (hidden) e trasferito con il
normale meccanismo action/post. Meglio sia invisibile per non fornire informazioni
sulla struttura delle tabelle a malintenzionati.

Il campo hidden viene costruito al volo controllando l'evento click sul bottone di submit
richiamando una funzione javascript
-->
<body>
  <form  method="post" name="cerca" action="eRicerca.php" id="cerca" onsubmit="false">
    <table>

        <tr>
          <td>Cognome o parte di esso</td>

          <td><input id="cognome" name="cognome"></td>
        </tr>

   
    </table> <br>
    <input type="hidden" id="comandoSQL" name="comandoSQL">
			
    <input id="cerca" value="CERCA" type="submit" name="cerca" onclick="costruisciStringaSQL();">
  </form>
</body>
</html>
