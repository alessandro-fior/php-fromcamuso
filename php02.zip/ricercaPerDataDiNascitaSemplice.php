<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">

<html>
<head>
  <title>Ricerca</title>
  </head>

<body>
  <form  method="post" name="cerca" action="eRicercaPerDataDiNascitaSemplice.php" id="cerca">
    <table>

        <tr>
          <td>Da data</td>

          <td><input id="daData" name="daData"></td>
        </tr>

        <tr>
          <td>A data</td>

          <td><input id="aData" name="aData"></td>
        </tr>

   
    </table> <br>
		
    <input id="cerca" value="CERCA" type="submit" name="cerca">
  </form>
</body>
</html>
