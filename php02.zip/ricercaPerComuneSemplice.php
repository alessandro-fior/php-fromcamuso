<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">

<html>
<head>
  <title>Ricerca</title>

  </head>

<body>
  <form  method="post" name="cerca" action="eRicercaPerComuneSemplice.php" id="cerca">
    <table>

		<td> Comune </td>
		<td>
		  <select name="elencoComuni" id="elencoComuni">
		  <option value="-1" selected> --- Scegli --- </option>
		    
      
		  <?php
        //costruisco combo comuni
				$conn = mysql_connect("localhost", "root", "") or die("Problemi nello stabilire la connessione");
				mysql_select_db("utenti") or die("Errore di accesso al data base utenti");

				$comando = "select * from comuni";
				$result = mysql_query($comando);

		    while ($dati = mysql_fetch_assoc($result))
  	   		 echo "<option value='$dati[idComune]'> $dati[nomeComune] </option>";
					 
				mysql_close();
		  ?>
		  
		  </select> <span style="color: red; font-weight: bold;"> <<<< costruita con codice PHP </span>
		
		</td>
		
    </table> <br>
			
    <input id="cerca" value="CERCA" type="submit" name="cerca">
  </form>
</body>
</html>
