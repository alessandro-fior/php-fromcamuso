<?php session_start(); ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">

<html>
<head>
  <title>Registra nel DB</title>
</head>

<body>
<?php
     
  //raccolgo i dati dalla form
  $cognome = $_REQUEST["cognome"];
  $nome = $_REQUEST["nome"];
  $ksComune = $_REQUEST["elencoComuni"];
  $userName = $_REQUEST["user"];
  $psw = $_REQUEST["psw"];
  
  //restituisce true/false
  $conn = mysql_connect("localhost", "root", "");
  
  if (!$conn)
  {
    mysql_close($conn); 
    die("Problemi nello stabilire la connessione");
  }	
  
  if (!mysql_select_db("utenti"))
  {
    mysql_close($conn); 
    die("Errore di accesso al data base utenti");
  }
 					  
  $comando = "update utenti_registrati set cognome='$cognome', nome='$nome', " .
             "userName='$userName', psw='$psw', ksComune='$ksComune' " .
			 "where idUtente='$_SESSION[idUtente]'";

  echo $comando;
  if (!mysql_query($comando))
    echo "Aggiornamento fallito <br />";
	
  
  //chiudo la connessione
  mysql_close($conn); 

  echo "<a href='index.html'> Torna al menu </a>";
 
?>
</body>
</html>
