<?php session_start(); ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">

<html>
<head>
  <title>Elimina</title>
</head>

<body>
<?php
  
 
$conn = mysql_connect("localhost", "root", "") or die("Problemi nello stabilire la connessione");
mysql_select_db("utenti") or die("Errore di accesso al data base utenti");

 					  
  $comando = "delete from utenti_registrati " .
			 "where idUtente='$_REQUEST[idUtente]'";
  echo $comando;
  
  if (!mysql_query($comando))
    echo "Eliminazione fallita <br />";
	
  
  //chiudo la connessione
  mysql_close($conn); 

  print "<a href='index.html'> Torna al menu </a>";
 
?>
</body>
</html>
