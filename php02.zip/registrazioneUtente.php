<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">

<html>

<head>
  <title>Registrazione nuovo utente</title>
</head>

<body>
<?php
                  define("PG","3.14");
                  echo PG; 

?>
 	 <span style="color: blue;"> In questa pagina mostrero' come consentire la scelta di una chiave esterna (il codice ksComune nella
	 tabella 'utenti_registrati') con una tipica maschera che serve ad inserire un record in una tabella. </span>
  	<br/>	
  <form  method="post" name="registra" action="eRegistrazioneUtente.php" id="accesso">
    <table>
      <tr>
        <td>Cognome</td>

        <td><input type="text" id="cognome" name="cognome"></td>
      </tr>

      <tr>
        <td>Nome</td>

        <td><input type="text" id="nome" name="nome"></td>
      </tr>
		
		  <tr>
		    <td> Comune </td>
		    <td>
		 
		      <select name="elencoComuni">
<!--	 La combobobox viene costruita dal codice php: come value di ogni option verr� messo un ksComune e la
	 parte visibile sar� ovviamente costituita dal nome del comune
-->	
		  <?php
        $conn = mysql_connect("localhost", "root", "") or die("Problemi nello stabilire la connessione");
        mysql_select_db("utenti") or die("Errore di accesso al data base utenti");
   					    
        $result = mysql_query("select * from comuni"); //nota: con una sola connessione si pu� evitare ,$conn
	
		    while ($dati = mysql_fetch_assoc($result) ) //con mysql_fetch_array si accede sia associativamente sia per posizione
  	   		 echo "<option value='$dati[idComune]'> $dati[nomeComune] </option>";
		  ?>
		      </select> <span style="color: red; font-weight: bold;"> <<<< costruita con codice PHP </span>
				</td>
  		</tr>

		  <tr>
		    <td> Avatar </td>
		    <td>
		 
		      <select name="elencoAvatar">
<!--	 La combobobox viene costruita dal codice php: come value di ogni option verr� messo un ksAvatar e la
	 parte visibile sar� ovviamente costituita dal nome dell'avatar
-->	
		  <?php
     					    
        $result = mysql_query("select * from avatar"); //nota: con una sola connessione si pu� evitare ,$conn
	
		    while ($dati = mysql_fetch_assoc($result))
  	   		 echo "<option value='$dati[idAvatar]'> $dati[descrizioneAvatar] </option>";
					 
				mysql_close();
		  ?>
		      </select> <span style="color: red; font-weight: bold;"> <<<< costruita con codice PHP </span>
				</td>
  		</tr>

      <tr>
        <td>Data Nascita (aaaa-mm-gg) </td>

        <td> <input id="dataNascita" name="dataNascita"> </td>
      </tr>
		
      <tr>
        <td>Versione Browser utilizzata (se Firefox) </td>

        <td><input id="versione" name="versione"></td>
      </tr>

      
			<tr>
        <td>User Name</td>

        <td><input id="user" name="user"></td>
      </tr>

      <tr>
        <td>Password</td>

        <td><input id="psw" type="password" name="psw" </td>
      </tr>

    </table> <br>
 
    <input id="ok" value="REGISTRA" type="submit" name="OK">
  </form>
</body>
</html>
