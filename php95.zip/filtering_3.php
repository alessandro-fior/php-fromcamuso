<?php
$nl="<br />";

//simulo la ricezione di dati di post ...
$_POST["eta"]="35";
$_POST["tasso_interesse"]="1.25";
$_POST["tipo_pagamento"]="contanti";
$_POST["email"]="kg@bo.it";
//------------------------------------------

//funzioni di validazione (true==validato)
function valida_intero($dato)
{
		return $dato == strval(intval($dato));  //"3a5" -> 3 -> "3"
}

function valida_float($dato)
{
	 return $dato == strval(floatval($dato));
}

function valida_opzione($dato)
{
	 switch ($dato)
  {
    case 'contanti':
    case 'carta_credito':
    case 'assegno':
    case 'paypal':
        return true;
    break;
  }
		
		return false;
}

function valida_email($email)
{
	 $pattern = "/^[^@\s<&>]+@([-a-z0-9]+\.)+[a-z]{2,}$/i";
	 return preg_match( $pattern, $email ); 	
}




//usare a livello di software house una politica dei nomi condivisa
//Ad esempio: decidere che ogni dato da usare per le le elaborazioni
//DEVE essere la versione contenuta in un array chiamato $dati_verificati
//e MAI usare direttamente l'array $_POST
$dati_verificati = array();

if ( valida_intero($_POST["eta"]) )
  $dati_verificati["eta"]=$_POST["eta"];
//... codice vario
if (isset($dati_verificati["eta"]) )
  echo "Test su interi: ".$dati_verificati["eta"].$nl;
//---------------------------------------------------------------------------------------


if ( valida_float($_POST["tasso_interesse"]) )
  $dati_verificati["tasso_interesse"]=$_POST["tasso_interesse"];
//... codice vario
if (isset($dati_verificati["tasso_interesse"]) )
 echo "Test su float: ".$dati_verificati["tasso_interesse"].$nl;
//---------------------------------------------------------------------------------------


if ( valida_opzione($_POST["tipo_pagamento"]) )
  $dati_verificati["tipo_pagamento"]=$_POST["tipo_pagamento"];
//... codice vario
if (isset($dati_verificati["tipo_pagamento"]) )
 echo "Test su elenco opzioni: ".$dati_verificati["tipo_pagamento"].$nl;		
//---------------------------------------------------------------------------------------


if ( valida_email($_POST["email"]) )
  $dati_verificati["email"]=$_POST["email"];
//... codice vario
if (isset($dati_verificati["email"]) )
 echo "Test su email: ".$dati_verificati["email"].$nl;				
		
?>





